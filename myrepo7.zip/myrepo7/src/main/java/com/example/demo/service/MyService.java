package com.example.demo.service;

import com.example.demo.entity.MyEntity;
import com.example.demo.repo.MyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MyService {
    @Autowired
    MyRepository myRepository;
    public List<MyEntity> getValueFromTable(){
        return myRepository.findByName("name");
    }
    public void saveEntity(){
        var entity=new MyEntity();
        entity.setId(1L);
        myRepository.save(entity);
    }
}
