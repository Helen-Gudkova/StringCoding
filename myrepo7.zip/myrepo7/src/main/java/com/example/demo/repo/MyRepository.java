package com.example.demo.repo;

import com.example.demo.entity.MyEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MyRepository extends CrudRepository<MyEntity, Long> {
    public List<MyEntity> findByName(String name);
}
