package com.example.demo.entity;

import org.hibernate.annotations.Table;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MyEntity  {
    private Long id;

    public void setId(Long id) {
        this.id = id;
    }
    @Id
    public Long getId(){
        return id;
    }
    private String name;
    public String getName(){
        return name;
    }
}
